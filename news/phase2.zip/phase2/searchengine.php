<?php 
class searchengine
{
	
	
	function getArticles($request_data){

				$servername = "localhost";
				$username = "root";
				$password = "naveen123";
				$dbname = "newsdb";

				$article_data = array();

				

				// Create connection
				$conn = new mysqli($servername, $username, $password, $dbname);
				// Check connection
				if ($conn->connect_error) {
    					die("Connection failed: " . $conn->connect_error);
				} 


		if(isset($request_data) && !empty($request_data) && ($request_data!=0)){

				$sql = "SELECT media_contact_name FROM 5_md_media_contact WHERE media_contact_id=".$request_data;

				$result = $conn->query($sql);
				if ($result->num_rows > 0) {
    					// output data of each row

                    //SEARCH VIEW BEGIN

                       

                        $conn->query("CREATE OR REPLACE VIEW CurrentAuthors AS SELECT mc.media_contact_id, mc.media_contact_name, mcat.media_category_name, mc.media_contact_designation, md.desk_name, mo.media_organization_website, mo.media_organization_name FROM 5_md_media_contact AS mc LEFT JOIN 3_md_desk AS md ON mc.desk_id = md.desk_id LEFT JOIN 2_md_media_organization AS mo ON md.media_organization_id = mo.media_organization_id LEFT JOIN 1_md_media_category AS mcat ON mo.media_category_id=mcat.media_category_id WHERE mcat.media_category_id = 2 AND is_quick_link='Y'");

                        $searchView = $conn->query("SELECT * FROM CurrentAuthors WHERE media_contact_id='".$request_data."'");

                            //echo $searchView->num_rows;

                            if($searchView->num_rows > 0){

                                while($viewData=$searchView->fetch_array(MYSQLI_ASSOC))
                                        {
                                            echo $viewData['media_contact_name'];

                                            // http://www.malaysiakini.com/search/en?q=*&category=&author=Rk%20Anand&dateFrom=1998-01-01&dateTo=2016-10-15
                                            $searchstring=str_replace(" ", "%20", $viewData['media_contact_name']);

                                            $url="http://www.malaysiakini.com/search/en?q=*&category=&author=$searchstring";

                                            echo $url;

                                            
                                            $html = file_get_contents($url);
libxml_use_internal_errors(true); //Prevents Warnings, remove if desired
$dom = new DOMDocument();
$dom->loadHTML($html);
$body = "";
foreach($dom->getElementsByTagName("body")->item(0)->childNodes as $child) {
    $body .= $dom->saveHTML($child);
}
echo $body;


                                           

               
                

                                        }
                            }

                            else{

                                echo " NO Articles Found";
                            }

				}
        }


		$conn->close();
	}
}







//echo $sql;

 ?>